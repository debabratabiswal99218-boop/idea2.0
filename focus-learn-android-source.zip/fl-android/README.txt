FOCUS LEARN - ANDROID APP (build steps)

1. Install Android Studio (free) from developer.android.com/studio
2. New Project -> "Empty Views Activity"
     Name: FocusLearn
     Package name: com.focuslearn.app   (must match exactly)
     Language: Kotlin
     Minimum SDK: API 26
3. Replace app/src/main/java/com/focuslearn/app/MainActivity.kt with the MainActivity.kt from this zip.
4. Right-click "app" -> New -> Folder -> Assets Folder (accept defaults).
   Copy the 3 files from this zip's "assets" folder into app/src/main/assets/
   (style.css, inject.js, gems.html).
5. Open app/src/main/AndroidManifest.xml and add this line just above the <application> tag:
     <uses-permission android:name="android.permission.INTERNET" />
6. Build the APK:  Build -> Build Bundle(s)/APK(s) -> Build APK(s)
   Output: app/build/outputs/apk/debug/app-debug.apk
7. Copy the APK to your phone, tap it, and allow "Install unknown apps" when asked.
   (Or plug the phone in with USB debugging on and press the green Run button.)

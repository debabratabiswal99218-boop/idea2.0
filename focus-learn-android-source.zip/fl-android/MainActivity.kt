package com.focuslearn.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import org.json.JSONObject
import java.io.ByteArrayInputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var root: LinearLayout
    private lateinit var strictBtn: Button
    private var strict = false
    private var customView: View? = null
    private lateinit var css: String
    private lateinit var js: String

    private val home = "https://m.youtube.com/"
    private val adHints = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "/pagead/", "/api/stats/ads", "adservice.google"
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("fl", MODE_PRIVATE)
        strict = prefs.getBoolean("strict", false)
        css = assets.open("style.css").bufferedReader().use { it.readText() }
        js = assets.open("inject.js").bufferedReader().use { it.readText() }

        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                customView = view
                (window.decorView as FrameLayout).addView(view)
                root.visibility = View.GONE
            }
            override fun onHideCustomView() {
                customView?.let { (window.decorView as FrameLayout).removeView(it) }
                customView = null
                root.visibility = View.VISIBLE
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                val host = u.host ?: ""
                val path = u.path ?: ""
                if (host.endsWith("youtube.com") && path.startsWith("/shorts/")) {
                    val id = path.removePrefix("/shorts/").substringBefore("/")
                    v.loadUrl("https://m.youtube.com/watch?v=$id")
                    return true
                }
                if (u.scheme == "file" || host.endsWith("youtube.com") ||
                    host.endsWith("google.com") || host.endsWith("gstatic.com")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val s = r.url.toString()
                if (adHints.any { s.contains(it) })
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                return null
            }

            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) = injectIfYoutube(url)
            override fun onPageFinished(v: WebView, url: String) = injectIfYoutube(url)
            override fun doUpdateVisitedHistory(v: WebView, url: String, isReload: Boolean) = injectIfYoutube(url)
        }

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
            bar.addView(this, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        btn("Home") { web.loadUrl(home) }
        btn("Hidden gems") { web.loadUrl("file:///android_asset/gems.html") }
        strictBtn = btn("") {
            strict = !strict
            prefs.edit().putBoolean("strict", strict).apply()
            updateStrictLabel()
            web.evaluateJavascript("window.__FL_MODE='${mode()}';window.__flScan&&window.__flScan();", null)
        }
        updateStrictLabel()

        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bar)
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener { v, insets ->
                val i = insets.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(i.left, i.top, i.right, i.bottom)
                insets
            }
        }
        web.loadUrl(home)
    }

    private fun mode() = if (strict) "strict" else "block"
    private fun updateStrictLabel() { strictBtn.text = if (strict) "Mode: Strict" else "Mode: Normal" }

    private fun injectIfYoutube(url: String?) {
        if (url == null || !url.contains("youtube.com")) return
        val setup = "window.__FL_MODE='${mode()}';" +
            "(function(){var s=document.getElementById('fl-style');" +
            "if(!s&&document.head){s=document.createElement('style');s.id='fl-style';" +
            "s.textContent=${JSONObject.quote(css)};document.head.appendChild(s);}})();"
        web.evaluateJavascript(setup + js, null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}

(function () {
  if (window.__flLoaded) { if (window.__flScan) window.__flScan(); return; }
  window.__flLoaded = true;

  // Edit these lists to suit you
  var BLOCK = "dance,dancing,choreography,twerk,tiktok,reels,#shorts,prank,challenge,meme,funny,viral,trending,reaction,gossip,roast,remix,item song,bollywood".split(",");
  var STUDY = "learn,tutorial,course,lecture,explained,explanation,how to,how does,science,physics,chemistry,math,biology,history,economics,programming,coding,python,javascript,engineering,philosophy,psychology,documentary,study,exam,university,research,algorithm,skills,book summary".split(",");
  var ITEMS = "ytm-rich-item-renderer, ytm-video-with-context-renderer, ytm-compact-video-renderer, ytm-media-item, yt-lockup-view-model, ytd-rich-item-renderer, ytd-video-renderer";

  function hide(el, on) {
    if (on) { el.style.display = "none"; el.dataset.flHidden = "1"; }
    else if (el.dataset.flHidden) { el.style.display = ""; delete el.dataset.flHidden; }
  }

  function scan() {
    var m = location.pathname.match(/^\/shorts\/([\w-]+)/);
    if (m) { location.replace("/watch?v=" + m[1]); return; }

    // Shorts tab in bottom bar
    document.querySelectorAll("ytm-pivot-bar-item-renderer").forEach(function (el) {
      if ((el.innerText || "").trim().toLowerCase() === "shorts") hide(el, true);
    });
    // Sections that contain Shorts links
    document.querySelectorAll("ytm-rich-section-renderer").forEach(function (el) {
      if (el.querySelector('a[href^="/shorts/"]')) hide(el, true);
    });

    var strict = window.__FL_MODE === "strict" && location.pathname.indexOf("/results") !== 0;
    document.querySelectorAll(ITEMS).forEach(function (el) {
      var text = (el.innerText || "").toLowerCase();
      if (!text.trim()) return;
      var bad = !!el.querySelector('a[href^="/shorts/"]') ||
        BLOCK.some(function (w) { return text.indexOf(w) !== -1; }) ||
        (strict && !STUDY.some(function (w) { return text.indexOf(w) !== -1; }));
      hide(el, bad);
    });
  }
  window.__flScan = scan;

  var t;
  new MutationObserver(function () { clearTimeout(t); t = setTimeout(scan, 250); })
    .observe(document.documentElement, { childList: true, subtree: true });

  // Auto-skip video ads
  setInterval(function () {
    var p = document.querySelector(".html5-video-player");
    if (!p || !p.classList.contains("ad-showing")) return;
    var v = p.querySelector("video");
    if (v && isFinite(v.duration) && v.duration > 0) v.currentTime = v.duration;
    document.querySelectorAll(".ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button__text")
      .forEach(function (b) { b.click(); });
  }, 300);

  scan();
})();
